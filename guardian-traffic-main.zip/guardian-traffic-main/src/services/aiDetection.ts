import { supabase } from "@/integrations/supabase/client";
import type { DetectionResult } from "@/types/detection";

export async function analyzeFrame(
  imageBase64: string,
  frameTimestamp: number,
  sourceVideo: string
): Promise<DetectionResult> {
  const { data, error } = await supabase.functions.invoke("analyze-frame", {
    body: { imageBase64, frameTimestamp, sourceVideo },
  });

  if (error) {
    throw new Error(error.message || "Failed to analyze frame");
  }

  if (!data?.success) {
    throw new Error(data?.error || "Analysis failed");
  }

  return data.detection as DetectionResult;
}
