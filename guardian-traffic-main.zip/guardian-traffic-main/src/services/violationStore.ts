import { supabase } from "@/integrations/supabase/client";
import type { DetectionResult } from "@/types/detection";

export async function saveViolations(
  detection: DetectionResult,
  frameTimestamp: number,
  sourceVideo: string
): Promise<number> {
  if (!detection.violations.length) return 0;

  const rows = detection.violations.map((v) => ({
    violation_type: v.type,
    description: v.description,
    severity: v.severity,
    fine: v.fine,
    plate: v.plate,
    confidence: v.confidence,
    vehicle_type: detection.vehicles[0]?.type || null,
    frame_timestamp: frameTimestamp,
    source_video: sourceVideo,
    overall_risk: detection.overall_risk,
    summary: detection.summary,
  }));

  const { error } = await supabase.from("violations").insert(rows);
  if (error) {
    console.error("Failed to save violations:", error);
    throw new Error("Failed to save violations to database");
  }
  return rows.length;
}
