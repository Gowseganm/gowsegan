import { Camera, AlertTriangle, Eye, IndianRupee, Clock, Target } from "lucide-react";
import { dashboardStats } from "@/data/mockData";

const stats = [
  { icon: Camera, label: "Active Cameras", value: `${dashboardStats.activeCameras}/${dashboardStats.totalCameras}`, color: "text-primary" },
  { icon: AlertTriangle, label: "Violations Today", value: dashboardStats.totalViolationsToday.toString(), color: "text-destructive" },
  { icon: Eye, label: "Detections", value: dashboardStats.totalDetectionsToday.toLocaleString(), color: "text-accent" },
  { icon: IndianRupee, label: "Fines Collected", value: `₹${(dashboardStats.finesCollected / 1000).toFixed(1)}K`, color: "text-success" },
  { icon: Clock, label: "Avg Response", value: `${dashboardStats.avgResponseTime}s`, color: "text-warning" },
  { icon: Target, label: "AI Accuracy", value: `${dashboardStats.accuracyRate}%`, color: "text-primary" },
];

const StatsBar = () => (
  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
    {stats.map(({ icon: Icon, label, value, color }) => (
      <div key={label} className="glass-panel p-4 flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <Icon className={`w-4 h-4 ${color}`} />
          <span className="text-xs text-muted-foreground uppercase tracking-wider font-mono">{label}</span>
        </div>
        <span className={`text-2xl font-bold font-mono ${color}`}>{value}</span>
      </div>
    ))}
  </div>
);

export default StatsBar;
