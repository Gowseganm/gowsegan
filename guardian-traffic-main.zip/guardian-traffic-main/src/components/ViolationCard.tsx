import { AlertTriangle, CheckCircle, XCircle, Clock, CreditCard } from "lucide-react";
import type { Violation } from "@/data/mockData";

const severityStyles = {
  high: "border-destructive/40 bg-destructive/5",
  medium: "border-warning/40 bg-warning/5",
  low: "border-primary/40 bg-primary/5",
};

const statusConfig = {
  pending: { icon: Clock, label: "Pending Review", className: "text-warning" },
  approved: { icon: CheckCircle, label: "Approved", className: "text-success" },
  rejected: { icon: XCircle, label: "Rejected", className: "text-destructive" },
  paid: { icon: CreditCard, label: "Paid", className: "text-primary" },
};

const ViolationCard = ({ violation }: { violation: Violation }) => {
  const status = statusConfig[violation.status];
  const StatusIcon = status.icon;

  return (
    <div className={`glass-panel p-4 border ${severityStyles[violation.severity]} transition-all hover:scale-[1.01]`}>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <AlertTriangle className={`w-4 h-4 ${violation.severity === "high" ? "text-destructive" : violation.severity === "medium" ? "text-warning" : "text-primary"}`} />
          <span className="font-semibold text-sm">{violation.type}</span>
        </div>
        <span className="text-xs font-mono text-muted-foreground">{violation.id}</span>
      </div>

      <div className="space-y-1.5 text-xs text-muted-foreground font-mono">
        <div className="flex justify-between">
          <span>Plate</span>
          <span className="text-foreground font-semibold">{violation.plate}</span>
        </div>
        <div className="flex justify-between">
          <span>Location</span>
          <span className="text-foreground">{violation.location}</span>
        </div>
        <div className="flex justify-between">
          <span>Time</span>
          <span>{violation.timestamp.split(" ")[1]}</span>
        </div>
        <div className="flex justify-between">
          <span>Confidence</span>
          <span className={violation.confidence > 90 ? "text-success" : "text-warning"}>{violation.confidence}%</span>
        </div>
        {violation.fine > 0 && (
          <div className="flex justify-between">
            <span>Fine</span>
            <span className="text-foreground font-semibold">₹{violation.fine}</span>
          </div>
        )}
      </div>

      <div className="mt-3 pt-3 border-t border-border/50 flex items-center gap-2">
        <StatusIcon className={`w-3.5 h-3.5 ${status.className}`} />
        <span className={`text-xs font-medium ${status.className}`}>{status.label}</span>
      </div>
    </div>
  );
};

export default ViolationCard;
