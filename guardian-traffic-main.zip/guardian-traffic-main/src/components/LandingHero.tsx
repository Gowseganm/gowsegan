import { Shield, Camera, Brain, Zap } from "lucide-react";
import { useNavigate } from "react-router-dom";
import heroImage from "@/assets/hero-traffic.jpg";

const LandingHero = () => {
  const navigate = useNavigate();

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img src={heroImage} alt="Smart city traffic monitoring" className="w-full h-full object-cover" width={1920} height={1080} />
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background" />
        <div className="absolute inset-0 grid-pattern opacity-30" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-primary/30 bg-primary/5 mb-8" style={{ animation: "fade-in-up 0.6s ease-out forwards" }}>
          <span className="w-2 h-2 rounded-full bg-primary animate-pulse-neon" />
          <span className="text-sm font-mono text-primary tracking-wider uppercase">AI-Powered System Active</span>
        </div>

        <h1
          className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tight mb-6 neon-text leading-[0.95]"
          style={{ animation: "fade-in-up 0.6s ease-out 0.1s forwards", opacity: 0, color: "hsl(var(--primary))" }}
        >
          Smart Traffic
          <br />
          <span className="text-foreground">Guardian</span>
        </h1>

        <p
          className="max-w-2xl text-lg md:text-xl text-muted-foreground mb-10 leading-relaxed"
          style={{ animation: "fade-in-up 0.6s ease-out 0.2s forwards", opacity: 0 }}
        >
          AI-powered real-time traffic violation detection, automated enforcement, and smart city analytics — 
          all from a single command center.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 mb-20" style={{ animation: "fade-in-up 0.6s ease-out 0.3s forwards", opacity: 0 }}>
          <button
            onClick={() => navigate("/dashboard")}
            className="px-8 py-4 rounded-lg font-semibold text-primary-foreground bg-primary hover:bg-primary/90 transition-all neon-border"
          >
            Open Dashboard
          </button>
          <button
            onClick={() => navigate("/admin")}
            className="px-8 py-4 rounded-lg font-semibold text-foreground bg-secondary hover:bg-secondary/80 transition-all border border-border"
          >
            Admin Panel
          </button>
        </div>

        {/* Feature cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl w-full" style={{ animation: "fade-in-up 0.6s ease-out 0.4s forwards", opacity: 0 }}>
          {[
            { icon: Camera, label: "48 Live Cameras", sub: "Real-time feeds" },
            { icon: Brain, label: "YOLOv8 AI", sub: "Object detection" },
            { icon: Shield, label: "Auto Fines", sub: "Instant enforcement" },
            { icon: Zap, label: "<1.2s Response", sub: "Edge processing" },
          ].map(({ icon: Icon, label, sub }) => (
            <div key={label} className="glass-panel p-4 flex flex-col items-center gap-2 hover:border-primary/40 transition-colors">
              <Icon className="w-6 h-6 text-primary" />
              <span className="font-semibold text-sm">{label}</span>
              <span className="text-xs text-muted-foreground">{sub}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LandingHero;
