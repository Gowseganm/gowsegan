import { useState, useRef, useCallback, useEffect } from "react";
import {
  Camera, Upload, Play, Pause, Image, Trash2, AlertTriangle,
  Brain, Shield, Car, Users, Loader2, CheckCircle, XCircle
} from "lucide-react";
import { analyzeFrame } from "@/services/aiDetection";
import { saveViolations } from "@/services/violationStore";
import type { FrameAnalysis, DetectionResult } from "@/types/detection";
import { toast } from "sonner";

type Mode = "live" | "upload";

const severityColor = {
  high: "text-destructive",
  medium: "text-warning",
  low: "text-primary",
  safe: "text-success",
};

const LiveFeedPanel = () => {
  const [mode, setMode] = useState<Mode>("live");
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [frames, setFrames] = useState<FrameAnalysis[]>([]);
  const [extractionProgress, setExtractionProgress] = useState(0);
  const [totalFrames, setTotalFrames] = useState(0);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [selectedFrame, setSelectedFrame] = useState<FrameAnalysis | null>(null);
  const [allDetections, setAllDetections] = useState<DetectionResult[]>([]);
  const [rtspUrl, setRtspUrl] = useState("");
  const [dragOver, setDragOver] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    return () => { if (videoUrl) URL.revokeObjectURL(videoUrl); };
  }, [videoUrl]);

  const handleFileSelect = useCallback((file: File) => {
    if (!file.type.match(/video/) && !file.name.match(/\.(mp4|avi|webm|mov)$/i)) {
      toast.error("Please upload a valid video file (MP4, AVI, WebM, MOV)");
      return;
    }
    if (file.size > 500 * 1024 * 1024) {
      toast.error("File size exceeds 500MB limit");
      return;
    }
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    setVideoFile(file);
    setVideoUrl(URL.createObjectURL(file));
    setFrames([]);
    setAllDetections([]);
    setSelectedFrame(null);
    setExtractionProgress(0);
    setIsPlaying(false);
  }, [videoUrl]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  }, [handleFileSelect]);

  const togglePlayPause = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) { videoRef.current.play(); setIsPlaying(true); }
    else { videoRef.current.pause(); setIsPlaying(false); }
  };

  const extractFrames = useCallback(async () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || !videoUrl) return;

    setIsExtracting(true);
    setFrames([]);
    setAllDetections([]);
    setSelectedFrame(null);
    video.pause();
    setIsPlaying(false);

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const duration = video.duration;
    const interval = 2;
    const frameCount = Math.min(Math.floor(duration / interval), 30); // cap at 30 frames
    setTotalFrames(frameCount);

    const newFrames: FrameAnalysis[] = [];

    for (let i = 0; i < frameCount; i++) {
      const time = i * interval;
      video.currentTime = time;

      await new Promise<void>((resolve) => {
        const onSeeked = () => {
          video.removeEventListener("seeked", onSeeked);
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL("image/jpeg", 0.7);
          newFrames.push({ frameId: i, timestamp: time, dataUrl, status: "pending" });
          setFrames([...newFrames]);
          setExtractionProgress(i + 1);
          resolve();
        };
        video.addEventListener("seeked", onSeeked);
      });
    }

    setIsExtracting(false);
    toast.success(`Extracted ${frameCount} frames. Click "Analyze All with AI" to detect violations.`);
  }, [videoUrl]);

  const analyzeAllFrames = useCallback(async () => {
    if (frames.length === 0) return;

    setIsAnalyzing(true);
    setAnalysisProgress(0);
    const detections: DetectionResult[] = [];
    const updatedFrames = [...frames];

    for (let i = 0; i < updatedFrames.length; i++) {
      const frame = updatedFrames[i];
      updatedFrames[i] = { ...frame, status: "analyzing" };
      setFrames([...updatedFrames]);
      setAnalysisProgress(i);

      try {
        const result = await analyzeFrame(
          frame.dataUrl,
          frame.timestamp,
          videoFile?.name || "uploaded_video"
        );
        updatedFrames[i] = { ...frame, status: "done", detection: result };
        detections.push(result);

        if (result.violations.length > 0) {
          toast.warning(`Frame ${i + 1}: ${result.violations.length} violation(s) detected!`);
          try {
            await saveViolations(result, frame.timestamp, videoFile?.name || "uploaded_video");
          } catch (e) {
            console.error("Failed to save violations:", e);
          }
        }
      } catch (err: any) {
        console.error(`Frame ${i} analysis error:`, err);
        updatedFrames[i] = { ...frame, status: "error", error: err.message };
        toast.error(`Frame ${i + 1}: ${err.message}`);
      }

      setFrames([...updatedFrames]);

      // Small delay between API calls to avoid rate limiting
      if (i < updatedFrames.length - 1) {
        await new Promise((r) => setTimeout(r, 1500));
      }
    }

    setAllDetections(detections);
    setAnalysisProgress(updatedFrames.length);
    setIsAnalyzing(false);
    toast.success("AI analysis complete!");
  }, [frames, videoFile]);

  const analyzeSingleFrame = useCallback(async (frameIndex: number) => {
    const updatedFrames = [...frames];
    const frame = updatedFrames[frameIndex];
    updatedFrames[frameIndex] = { ...frame, status: "analyzing" };
    setFrames([...updatedFrames]);

    try {
      const result = await analyzeFrame(frame.dataUrl, frame.timestamp, videoFile?.name || "video");
      updatedFrames[frameIndex] = { ...frame, status: "done", detection: result };
      setFrames([...updatedFrames]);
      setSelectedFrame(updatedFrames[frameIndex]);
      if (result.violations.length > 0) {
        toast.warning(`${result.violations.length} violation(s) detected!`);
        try {
          await saveViolations(result, frame.timestamp, videoFile?.name || "video");
        } catch (e) {
          console.error("Failed to save violations:", e);
        }
      } else {
        toast.success("No violations detected in this frame.");
      }
    } catch (err: any) {
      updatedFrames[frameIndex] = { ...frame, status: "error", error: err.message };
      setFrames([...updatedFrames]);
      toast.error(err.message);
    }
  }, [frames, videoFile]);

  const clearVideo = () => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    setVideoFile(null);
    setVideoUrl(null);
    setFrames([]);
    setAllDetections([]);
    setSelectedFrame(null);
    setExtractionProgress(0);
    setIsPlaying(false);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const formatTime = (s: number) => `${Math.floor(s / 60)}:${Math.floor(s % 60).toString().padStart(2, "0")}`;

  // Aggregate stats
  const totalViolations = allDetections.reduce((s, d) => s + d.violations.length, 0);
  const totalVehicles = allDetections.reduce((s, d) => s + d.vehicle_count, 0);
  const totalPersons = allDetections.reduce((s, d) => s + d.person_count, 0);
  const plates = [...new Set(allDetections.flatMap((d) => d.vehicles.map((v) => v.plate).filter(Boolean)))];

  return (
    <div className="glass-panel p-4 space-y-4">
      <input ref={fileInputRef} type="file" accept="video/mp4,video/avi,video/webm,video/quicktime,.mp4,.avi,.webm,.mov" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFileSelect(f); }} />
      <canvas ref={canvasRef} className="hidden" />

      {/* Mode toggle */}
      <div className="flex items-center gap-2">
        {(["live", "upload"] as Mode[]).map((m) => (
          <button key={m} onClick={() => setMode(m)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              mode === m ? "bg-primary text-primary-foreground neon-border" : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
            }`}>
            {m === "live" ? <Camera className="w-4 h-4" /> : <Upload className="w-4 h-4" />}
            {m === "live" ? "Live Mode" : "Upload Video"}
          </button>
        ))}
      </div>

      {mode === "live" ? (
        <div className="space-y-3">
          <div className="relative aspect-video rounded-lg bg-gradient-to-br from-secondary to-background overflow-hidden border border-border/50">
            <div className="absolute inset-0 scanline" />
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
              <Camera className="w-10 h-10 text-muted-foreground/30" />
              <p className="text-sm text-muted-foreground">Enter RTSP/IP camera URL below</p>
            </div>
            <div className="absolute top-3 left-3">
              <div className="flex items-center gap-2 px-2 py-1 rounded bg-destructive/20 text-xs font-mono text-destructive">
                <span className="w-1.5 h-1.5 rounded-full bg-destructive animate-pulse" /> LIVE
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <input type="text" placeholder="rtsp://192.168.1.100:554/stream" value={rtspUrl} onChange={(e) => setRtspUrl(e.target.value)}
              className="flex-1 px-4 py-2.5 rounded-lg bg-secondary border border-border text-sm font-mono text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50" />
            <button className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">Connect</button>
          </div>
          <p className="text-xs text-muted-foreground">
            <strong>Note:</strong> RTSP streams need a backend proxy to transcode for browsers. The uploaded video mode works fully with AI analysis.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {videoUrl ? (
            <>
              {/* Video player */}
              <div className="relative rounded-lg overflow-hidden border border-border/50">
                <video ref={videoRef} src={videoUrl} className="w-full aspect-video object-contain bg-background"
                  onEnded={() => setIsPlaying(false)} onPause={() => setIsPlaying(false)} onPlay={() => setIsPlaying(true)} />
                <div className="absolute top-3 left-3 flex items-center gap-2 px-2 py-1 rounded bg-background/80 backdrop-blur text-xs font-mono">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                  {videoFile?.name}
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-2 flex-wrap">
                <button onClick={togglePlayPause} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-secondary text-sm font-medium hover:bg-secondary/80 transition-colors">
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  {isPlaying ? "Pause" : "Play"}
                </button>
                <button onClick={extractFrames} disabled={isExtracting || isAnalyzing}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg bg-secondary text-sm font-medium hover:bg-secondary/80 transition-colors disabled:opacity-50">
                  <Image className="w-4 h-4" />
                  {isExtracting ? "Extracting..." : "Extract Frames"}
                </button>
                {frames.length > 0 && !isAnalyzing && (
                  <button onClick={analyzeAllFrames}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-colors neon-border">
                    <Brain className="w-4 h-4" />
                    Analyze All with AI
                  </button>
                )}
                <button onClick={clearVideo} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-destructive/10 text-destructive text-sm font-medium hover:bg-destructive/20 transition-colors ml-auto">
                  <Trash2 className="w-4 h-4" /> Remove
                </button>
              </div>

              {/* Progress bars */}
              {isExtracting && (
                <div className="glass-panel p-3 space-y-2">
                  <div className="flex justify-between text-xs font-mono text-muted-foreground">
                    <span>Extracting frames...</span>
                    <span>{extractionProgress}/{totalFrames}</span>
                  </div>
                  <div className="w-full h-1.5 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${totalFrames > 0 ? (extractionProgress / totalFrames) * 100 : 0}%` }} />
                  </div>
                </div>
              )}

              {isAnalyzing && (
                <div className="glass-panel p-3 space-y-2 neon-border">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="flex items-center gap-2 text-primary">
                      <Brain className="w-3.5 h-3.5 animate-pulse" /> AI analyzing frames...
                    </span>
                    <span className="text-muted-foreground">{analysisProgress}/{frames.length}</span>
                  </div>
                  <div className="w-full h-1.5 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${frames.length > 0 ? (analysisProgress / frames.length) * 100 : 0}%` }} />
                  </div>
                </div>
              )}

              {/* Frames grid */}
              {frames.length > 0 && (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                    Frames ({frames.length}) — Click to analyze individually
                  </h3>
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2 max-h-52 overflow-y-auto pr-1">
                    {frames.map((frame, idx) => (
                      <div key={frame.frameId} onClick={() => {
                        if (frame.status === "done") setSelectedFrame(frame);
                        else if (frame.status === "pending") analyzeSingleFrame(idx);
                      }}
                        className={`relative rounded overflow-hidden border cursor-pointer transition-all ${
                          selectedFrame?.frameId === frame.frameId ? "border-primary ring-1 ring-primary" :
                          frame.status === "done" && frame.detection?.violations?.length ? "border-destructive/50" :
                          frame.status === "done" ? "border-success/50" :
                          "border-border/50 hover:border-primary/40"
                        }`}>
                        <img src={frame.dataUrl} alt={`Frame ${formatTime(frame.timestamp)}`} className="w-full aspect-video object-cover" />
                        <div className="absolute bottom-0 inset-x-0 bg-background/80 backdrop-blur px-1.5 py-0.5 flex justify-between items-center">
                          <span className="text-[10px] font-mono text-muted-foreground">{formatTime(frame.timestamp)}</span>
                          {frame.status === "analyzing" && <Loader2 className="w-3 h-3 text-primary animate-spin" />}
                          {frame.status === "done" && !frame.detection?.violations?.length && <CheckCircle className="w-3 h-3 text-success" />}
                          {frame.status === "done" && (frame.detection?.violations?.length ?? 0) > 0 && <AlertTriangle className="w-3 h-3 text-destructive" />}
                          {frame.status === "error" && <XCircle className="w-3 h-3 text-destructive" />}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Aggregate stats */}
              {allDetections.length > 0 && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  <div className="glass-panel p-3 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-destructive" />
                    <div>
                      <p className="text-lg font-bold font-mono text-destructive">{totalViolations}</p>
                      <p className="text-[10px] text-muted-foreground uppercase">Violations</p>
                    </div>
                  </div>
                  <div className="glass-panel p-3 flex items-center gap-2">
                    <Car className="w-4 h-4 text-primary" />
                    <div>
                      <p className="text-lg font-bold font-mono text-primary">{totalVehicles}</p>
                      <p className="text-[10px] text-muted-foreground uppercase">Vehicles</p>
                    </div>
                  </div>
                  <div className="glass-panel p-3 flex items-center gap-2">
                    <Users className="w-4 h-4 text-accent" />
                    <div>
                      <p className="text-lg font-bold font-mono text-accent">{totalPersons}</p>
                      <p className="text-[10px] text-muted-foreground uppercase">Persons</p>
                    </div>
                  </div>
                  <div className="glass-panel p-3 flex items-center gap-2">
                    <Shield className="w-4 h-4 text-warning" />
                    <div>
                      <p className="text-lg font-bold font-mono text-warning">{plates.length}</p>
                      <p className="text-[10px] text-muted-foreground uppercase">Plates Read</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Selected frame detail */}
              {selectedFrame?.detection && (
                <FrameDetail frame={selectedFrame} />
              )}

              {/* All violations summary */}
              {allDetections.length > 0 && totalViolations > 0 && !selectedFrame && (
                <ViolationsSummary detections={allDetections} frames={frames} />
              )}
            </>
          ) : (
            <div className={`relative aspect-video rounded-lg border-2 border-dashed transition-all flex flex-col items-center justify-center gap-4 cursor-pointer ${
              dragOver ? "border-primary bg-primary/5" : "border-border/50 bg-gradient-to-br from-secondary to-background hover:border-primary/30"
            }`}
              onClick={() => fileInputRef.current?.click()}
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}>
              <Upload className={`w-12 h-12 ${dragOver ? "text-primary" : "text-muted-foreground/40"}`} />
              <p className="text-sm text-foreground font-medium">{dragOver ? "Drop video here" : "Click to upload or drag & drop"}</p>
              <p className="text-xs text-muted-foreground font-mono">MP4, AVI, WebM, MOV • Max 500MB</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// --- Sub-components ---

const FrameDetail = ({ frame }: { frame: FrameAnalysis }) => {
  const d = frame.detection!;
  return (
    <div className="glass-panel p-4 space-y-3 neon-border">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <Brain className="w-4 h-4 text-primary" />
          AI Detection — Frame at {Math.floor(frame.timestamp / 60)}:{Math.floor(frame.timestamp % 60).toString().padStart(2, "0")}
        </h3>
        <span className={`text-xs font-mono font-semibold px-2 py-0.5 rounded ${severityColor[d.overall_risk]}`}>
          Risk: {d.overall_risk.toUpperCase()}
        </span>
      </div>

      <p className="text-sm text-muted-foreground">{d.summary}</p>

      {/* Vehicles */}
      {d.vehicles.length > 0 && (
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">Vehicles ({d.vehicle_count})</h4>
          <div className="flex flex-wrap gap-1.5">
            {d.vehicles.map((v, i) => (
              <span key={i} className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-secondary text-xs font-mono">
                <Car className="w-3 h-3 text-primary" />
                {v.type} {v.plate && <span className="text-foreground font-semibold ml-1">{v.plate}</span>}
                <span className="text-muted-foreground">({Math.round(v.confidence * 100)}%)</span>
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Violations */}
      {d.violations.length > 0 && (
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wider text-destructive mb-1">⚠ Violations ({d.violations.length})</h4>
          <div className="space-y-1.5">
            {d.violations.map((v, i) => (
              <div key={i} className="flex items-start justify-between p-2 rounded bg-destructive/5 border border-destructive/20">
                <div>
                  <span className="text-sm font-medium text-destructive">{v.type.replace(/_/g, " ").toUpperCase()}</span>
                  <p className="text-xs text-muted-foreground">{v.description}</p>
                  {v.plate && <p className="text-xs font-mono font-semibold mt-0.5">Plate: {v.plate}</p>}
                </div>
                <div className="text-right">
                  <span className="text-sm font-bold font-mono">₹{v.fine}</span>
                  <p className="text-[10px] text-muted-foreground">{Math.round(v.confidence * 100)}% conf</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Accidents */}
      {d.accidents.length > 0 && (
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wider text-destructive mb-1">🚨 Accidents</h4>
          {d.accidents.map((a, i) => (
            <div key={i} className="p-2 rounded bg-destructive/10 border border-destructive/30 text-sm">
              {a.description} <span className="text-xs text-muted-foreground">({Math.round(a.confidence * 100)}%)</span>
            </div>
          ))}
        </div>
      )}

      {/* Abnormal activities */}
      {d.abnormal_activities.length > 0 && (
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wider text-warning mb-1">⚡ Abnormal Activities</h4>
          {d.abnormal_activities.map((a, i) => (
            <div key={i} className="p-2 rounded bg-warning/10 border border-warning/30 text-sm">
              {a.type}: {a.description} <span className="text-xs text-muted-foreground">({Math.round(a.confidence * 100)}%)</span>
            </div>
          ))}
        </div>
      )}

      <div className="flex gap-4 text-xs font-mono text-muted-foreground pt-2 border-t border-border/50">
        <span>Persons: {d.person_count}</span>
        <span>Vehicles: {d.vehicle_count}</span>
      </div>
    </div>
  );
};

const ViolationsSummary = ({ detections, frames }: { detections: DetectionResult[]; frames: FrameAnalysis[] }) => {
  const allViolations = detections.flatMap((d, i) =>
    d.violations.map((v) => ({ ...v, frameIndex: i, timestamp: frames.find((f) => f.status === "done")?.timestamp || 0 }))
  );

  return (
    <div className="glass-panel p-4 space-y-3">
      <h3 className="text-sm font-semibold flex items-center gap-2">
        <AlertTriangle className="w-4 h-4 text-destructive" />
        All Detected Violations ({allViolations.length})
      </h3>
      <div className="space-y-1.5 max-h-48 overflow-y-auto">
        {allViolations.map((v, i) => (
          <div key={i} className="flex items-center justify-between p-2 rounded bg-destructive/5 border border-destructive/20 text-sm">
            <div className="flex items-center gap-2">
              <AlertTriangle className={`w-3.5 h-3.5 ${severityColor[v.severity]}`} />
              <span className="font-medium">{v.type.replace(/_/g, " ")}</span>
              {v.plate && <span className="font-mono text-xs bg-secondary px-1.5 py-0.5 rounded">{v.plate}</span>}
            </div>
            <span className="font-bold font-mono">₹{v.fine}</span>
          </div>
        ))}
      </div>
      <div className="text-right text-sm font-mono">
        Total fines: <span className="text-destructive font-bold">₹{allViolations.reduce((s, v) => s + v.fine, 0).toLocaleString()}</span>
      </div>
    </div>
  );
};

export default LiveFeedPanel;
