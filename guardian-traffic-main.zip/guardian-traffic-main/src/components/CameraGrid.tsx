import { Camera, Wifi, WifiOff, Loader2 } from "lucide-react";
import { mockCameras } from "@/data/mockData";

const statusIcon = {
  online: <Wifi className="w-3 h-3 text-success" />,
  offline: <WifiOff className="w-3 h-3 text-destructive" />,
  processing: <Loader2 className="w-3 h-3 text-warning animate-spin" />,
};

const CameraGrid = () => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
    {mockCameras.map((cam) => (
      <div key={cam.id} className="glass-panel overflow-hidden group cursor-pointer hover:border-primary/40 transition-all">
        {/* Simulated feed */}
        <div className="relative h-32 bg-gradient-to-br from-secondary to-background flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 scanline opacity-50" />
          <Camera className="w-8 h-8 text-muted-foreground/30" />
          <div className="absolute top-2 left-2 flex items-center gap-1.5 px-2 py-0.5 rounded bg-background/80 backdrop-blur text-xs font-mono">
            {statusIcon[cam.status]}
            <span className="text-muted-foreground">{cam.id}</span>
          </div>
          {cam.status === "online" && (
            <div className="absolute top-2 right-2 flex items-center gap-1 px-2 py-0.5 rounded bg-destructive/20 text-xs font-mono text-destructive">
              <span className="w-1.5 h-1.5 rounded-full bg-destructive animate-pulse" />
              LIVE
            </div>
          )}
        </div>
        <div className="p-3">
          <p className="font-semibold text-sm truncate">{cam.name}</p>
          <p className="text-xs text-muted-foreground truncate mb-2">{cam.location}</p>
          <div className="flex justify-between text-xs font-mono text-muted-foreground">
            <span>Detections: <span className="text-foreground">{cam.detections}</span></span>
            <span>Violations: <span className="text-destructive">{cam.violations}</span></span>
          </div>
        </div>
      </div>
    ))}
  </div>
);

export default CameraGrid;
