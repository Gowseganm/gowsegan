import { Shield, LayoutDashboard, Users, Home } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";

const links = [
  { path: "/", icon: Home, label: "Home" },
  { path: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { path: "/admin", icon: Shield, label: "Admin" },
  { path: "/user", icon: Users, label: "User Portal" },
];

const DashboardNav = () => {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <nav className="glass-panel px-4 py-3 flex items-center justify-between sticky top-0 z-50">
      <div className="flex items-center gap-3">
        <Shield className="w-6 h-6 text-primary" />
        <span className="font-bold text-lg tracking-tight">
          <span className="text-primary neon-text">Traffic</span>
          <span className="text-foreground">Guardian</span>
        </span>
      </div>
      <div className="flex items-center gap-1">
        {links.map(({ path, icon: Icon, label }) => (
          <button
            key={path}
            onClick={() => navigate(path)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              location.pathname === path
                ? "bg-primary/10 text-primary border border-primary/20"
                : "text-muted-foreground hover:text-foreground hover:bg-secondary"
            }`}
          >
            <Icon className="w-4 h-4" />
            <span className="hidden md:inline">{label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
};

export default DashboardNav;
