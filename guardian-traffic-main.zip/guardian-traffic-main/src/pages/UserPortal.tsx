import { useState } from "react";
import { CreditCard, Download, AlertTriangle, CheckCircle } from "lucide-react";
import DashboardNav from "@/components/DashboardNav";
import { mockViolations } from "@/data/mockData";

const userViolations = mockViolations.filter((v) => v.plate === "MH-12-AB-1234" || v.plate === "KA-05-CD-5678");

const UserPortal = () => {
  const [paid, setPaid] = useState<Set<string>>(new Set());

  const handlePay = (id: string) => {
    setPaid((prev) => new Set(prev).add(id));
  };

  const totalPending = userViolations
    .filter((v) => v.status !== "rejected" && !paid.has(v.id) && v.fine > 0)
    .reduce((sum, v) => sum + v.fine, 0);

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />
      <main className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold mb-1">User Portal</h1>
          <p className="text-sm text-muted-foreground font-mono">View your violations and pay fines</p>
        </div>

        {/* Summary */}
        <div className="glass-panel p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Total Outstanding Fines</p>
            <p className="text-3xl font-bold font-mono text-destructive">₹{totalPending.toLocaleString()}</p>
          </div>
          <div className="text-sm text-muted-foreground font-mono">
            Registered Plates: <span className="text-foreground">MH-12-AB-1234, KA-05-CD-5678</span>
          </div>
        </div>

        {/* Violations */}
        <div className="space-y-3">
          {userViolations.map((v) => {
            const isPaid = paid.has(v.id) || v.status === "paid";
            return (
              <div key={v.id} className={`glass-panel p-5 ${isPaid ? "opacity-60" : ""}`}>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      {isPaid ? (
                        <CheckCircle className="w-4 h-4 text-success" />
                      ) : (
                        <AlertTriangle className={`w-4 h-4 ${v.severity === "high" ? "text-destructive" : "text-warning"}`} />
                      )}
                      <span className="font-semibold">{v.type}</span>
                      <span className="text-xs font-mono text-muted-foreground">{v.id}</span>
                    </div>
                    <div className="text-xs text-muted-foreground font-mono space-x-4">
                      <span>Plate: {v.plate}</span>
                      <span>{v.location}</span>
                      <span>{v.timestamp}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {v.fine > 0 && (
                      <span className="text-lg font-bold font-mono">₹{v.fine}</span>
                    )}
                    {isPaid ? (
                      <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-secondary text-sm font-medium text-muted-foreground">
                        <Download className="w-4 h-4" />
                        Receipt
                      </button>
                    ) : v.status !== "rejected" && v.fine > 0 ? (
                      <button
                        onClick={() => handlePay(v.id)}
                        className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors neon-border"
                      >
                        <CreditCard className="w-4 h-4" />
                        Pay Fine
                      </button>
                    ) : null}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
};

export default UserPortal;
