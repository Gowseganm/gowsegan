import DashboardNav from "@/components/DashboardNav";
import StatsBar from "@/components/StatsBar";
import LiveFeedPanel from "@/components/LiveFeedPanel";
import ViolationCard from "@/components/ViolationCard";
import CameraGrid from "@/components/CameraGrid";
import { mockViolations } from "@/data/mockData";

const Dashboard = () => (
  <div className="min-h-screen bg-background">
    <DashboardNav />
    <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Command Center</h1>
        <p className="text-sm text-muted-foreground font-mono">Real-time AI traffic monitoring & enforcement</p>
      </div>

      <StatsBar />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <LiveFeedPanel />
        </div>
        <div className="space-y-3">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Recent Violations</h2>
          {mockViolations.slice(0, 4).map((v) => (
            <ViolationCard key={v.id} violation={v} />
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-3">Camera Network</h2>
        <CameraGrid />
      </div>
    </main>
  </div>
);

export default Dashboard;
