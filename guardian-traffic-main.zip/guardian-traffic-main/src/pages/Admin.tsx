import { useState } from "react";
import { Search, CheckCircle, XCircle, Filter } from "lucide-react";
import DashboardNav from "@/components/DashboardNav";
import { mockViolations, type Violation } from "@/data/mockData";

const Admin = () => {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<string>("all");
  const [violations, setViolations] = useState<Violation[]>(mockViolations);

  const filtered = violations.filter((v) => {
    const matchesSearch = v.plate.toLowerCase().includes(search.toLowerCase()) ||
      v.type.toLowerCase().includes(search.toLowerCase()) ||
      v.id.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === "all" || v.status === filter;
    return matchesSearch && matchesFilter;
  });

  const updateStatus = (id: string, status: "approved" | "rejected") => {
    setViolations((prev) => prev.map((v) => (v.id === id ? { ...v, status } : v)));
  };

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />
      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold mb-1">Admin Panel</h1>
          <p className="text-sm text-muted-foreground font-mono">Review and manage AI-detected violations</p>
        </div>

        {/* Search & filters */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search by plate, type, or ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-secondary border border-border text-sm font-mono text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
            />
          </div>
          <div className="flex gap-2">
            {["all", "pending", "approved", "rejected", "paid"].map((s) => (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className={`px-3 py-2 rounded-lg text-xs font-medium capitalize transition-all ${
                  filter === s
                    ? "bg-primary/10 text-primary border border-primary/20"
                    : "bg-secondary text-muted-foreground hover:text-foreground"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div className="glass-panel overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border/50">
                  {["ID", "Type", "Plate", "Location", "Time", "Confidence", "Fine", "Status", "Actions"].map((h) => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border/30">
                {filtered.map((v) => (
                  <tr key={v.id} className="hover:bg-secondary/50 transition-colors">
                    <td className="px-4 py-3 text-sm font-mono text-muted-foreground">{v.id}</td>
                    <td className="px-4 py-3">
                      <span className={`text-sm font-medium ${v.severity === "high" ? "text-destructive" : v.severity === "medium" ? "text-warning" : "text-foreground"}`}>
                        {v.type}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm font-mono font-semibold">{v.plate}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{v.location}</td>
                    <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{v.timestamp.split(" ")[1]}</td>
                    <td className="px-4 py-3">
                      <span className={`text-sm font-mono ${v.confidence > 90 ? "text-success" : "text-warning"}`}>{v.confidence}%</span>
                    </td>
                    <td className="px-4 py-3 text-sm font-mono">₹{v.fine}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        v.status === "approved" ? "bg-success/10 text-success" :
                        v.status === "rejected" ? "bg-destructive/10 text-destructive" :
                        v.status === "paid" ? "bg-primary/10 text-primary" :
                        "bg-warning/10 text-warning"
                      }`}>
                        {v.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      {v.status === "pending" && (
                        <div className="flex gap-1">
                          <button onClick={() => updateStatus(v.id, "approved")} className="p-1.5 rounded hover:bg-success/10 transition-colors" title="Approve">
                            <CheckCircle className="w-4 h-4 text-success" />
                          </button>
                          <button onClick={() => updateStatus(v.id, "rejected")} className="p-1.5 rounded hover:bg-destructive/10 transition-colors" title="Reject">
                            <XCircle className="w-4 h-4 text-destructive" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 && (
            <div className="py-12 text-center text-sm text-muted-foreground">No violations found.</div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Admin;
