export interface DetectionResult {
  vehicles: Array<{
    type: string;
    plate: string | null;
    confidence: number;
  }>;
  violations: Array<{
    type: string;
    description: string;
    severity: "high" | "medium" | "low";
    fine: number;
    plate: string | null;
    confidence: number;
  }>;
  accidents: Array<{
    description: string;
    severity: "high" | "medium" | "low";
    confidence: number;
  }>;
  abnormal_activities: Array<{
    type: string;
    description: string;
    confidence: number;
  }>;
  person_count: number;
  vehicle_count: number;
  overall_risk: "high" | "medium" | "low" | "safe";
  summary: string;
}

export interface FrameAnalysis {
  frameId: number;
  timestamp: number;
  dataUrl: string;
  status: "pending" | "analyzing" | "done" | "error";
  detection?: DetectionResult;
  error?: string;
}
