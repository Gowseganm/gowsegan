export interface Violation {
  id: string;
  type: string;
  plate: string;
  location: string;
  timestamp: string;
  severity: "high" | "medium" | "low";
  fine: number;
  status: "pending" | "approved" | "rejected" | "paid";
  confidence: number;
  imageUrl?: string;
}

export interface CameraFeed {
  id: string;
  name: string;
  location: string;
  status: "online" | "offline" | "processing";
  detections: number;
  violations: number;
}

export const VIOLATION_TYPES = [
  "No Helmet",
  "No Seatbelt",
  "Triple Riding",
  "Signal Jumping",
  "Rash Driving",
  "Public Fighting",
  "Accident Detected",
  "Wrong Way",
  "Over Speeding",
] as const;

export const mockViolations: Violation[] = [
  { id: "V-001", type: "No Helmet", plate: "MH-12-AB-1234", location: "Junction A - Cam 03", timestamp: "2026-03-26 14:23:11", severity: "medium", fine: 500, status: "pending", confidence: 94.2 },
  { id: "V-002", type: "Signal Jumping", plate: "KA-05-CD-5678", location: "Main Road - Cam 07", timestamp: "2026-03-26 14:21:45", severity: "high", fine: 1000, status: "approved", confidence: 97.8 },
  { id: "V-003", type: "Triple Riding", plate: "DL-08-EF-9012", location: "Highway Entry - Cam 12", timestamp: "2026-03-26 14:19:30", severity: "medium", fine: 1000, status: "pending", confidence: 91.5 },
  { id: "V-004", type: "Accident Detected", plate: "TN-22-GH-3456", location: "Ring Road - Cam 01", timestamp: "2026-03-26 14:15:02", severity: "high", fine: 0, status: "approved", confidence: 98.1 },
  { id: "V-005", type: "No Seatbelt", plate: "GJ-01-IJ-7890", location: "Sector 5 - Cam 09", timestamp: "2026-03-26 14:12:18", severity: "low", fine: 500, status: "paid", confidence: 89.3 },
  { id: "V-006", type: "Over Speeding", plate: "RJ-14-KL-2345", location: "Expressway - Cam 15", timestamp: "2026-03-26 14:08:55", severity: "high", fine: 2000, status: "pending", confidence: 96.7 },
  { id: "V-007", type: "Wrong Way", plate: "UP-32-MN-6789", location: "One Way St - Cam 04", timestamp: "2026-03-26 14:05:33", severity: "high", fine: 1500, status: "rejected", confidence: 72.1 },
  { id: "V-008", type: "Rash Driving", plate: "MP-09-OP-0123", location: "School Zone - Cam 11", timestamp: "2026-03-26 14:02:10", severity: "high", fine: 2000, status: "approved", confidence: 95.4 },
];

export const mockCameras: CameraFeed[] = [
  { id: "CAM-01", name: "Ring Road Cam 01", location: "Ring Road Junction", status: "online", detections: 1247, violations: 23 },
  { id: "CAM-03", name: "Junction A Cam 03", location: "City Center Junction A", status: "online", detections: 892, violations: 15 },
  { id: "CAM-04", name: "One Way Cam 04", location: "One Way Street", status: "processing", detections: 534, violations: 8 },
  { id: "CAM-07", name: "Main Road Cam 07", location: "Main Road Intersection", status: "online", detections: 2103, violations: 41 },
  { id: "CAM-09", name: "Sector 5 Cam 09", location: "Residential Sector 5", status: "offline", detections: 0, violations: 0 },
  { id: "CAM-11", name: "School Zone Cam 11", location: "School Zone Area", status: "online", detections: 678, violations: 12 },
  { id: "CAM-12", name: "Highway Cam 12", location: "Highway Entry Point", status: "online", detections: 3201, violations: 67 },
  { id: "CAM-15", name: "Expressway Cam 15", location: "Expressway Toll Area", status: "online", detections: 4512, violations: 89 },
];

export const dashboardStats = {
  totalCameras: 48,
  activeCameras: 42,
  totalViolationsToday: 267,
  totalDetectionsToday: 15840,
  finesCollected: 234500,
  pendingReview: 43,
  accuracyRate: 94.7,
  avgResponseTime: 1.2,
};
