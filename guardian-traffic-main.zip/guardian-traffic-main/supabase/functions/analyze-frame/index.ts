import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { imageBase64, frameTimestamp, sourceVideo } = await req.json();

    if (!imageBase64) {
      return new Response(JSON.stringify({ error: "imageBase64 is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const systemPrompt = `You are an expert AI traffic monitoring system. Analyze the provided traffic camera image and detect ALL of the following:

1. **Vehicles**: Count and classify (car, bike, truck, bus, auto-rickshaw, etc.)
2. **License Plates**: Read any visible number plates and extract the text (Indian format like MH-12-AB-1234)
3. **Traffic Violations**: Detect any of these:
   - No helmet (motorcycle/scooter riders)
   - No seatbelt (car drivers/passengers)
   - Triple riding (3+ people on a two-wheeler)
   - Signal jumping / red light violation
   - Wrong way driving
   - Over speeding indicators (blurred motion)
   - Rash driving indicators
4. **Accidents**: Any collision, overturned vehicle, or crash scene
5. **Abnormal Activities**: Public fighting, jaywalking in dangerous areas, objects on road
6. **Persons**: Count visible people

You MUST respond with ONLY a valid JSON object (no markdown, no explanation) in this exact format:
{
  "vehicles": [{"type": "car|bike|truck|bus|auto", "plate": "XX-00-XX-0000 or null", "confidence": 0.0-1.0}],
  "violations": [{"type": "no_helmet|no_seatbelt|triple_riding|signal_jumping|wrong_way|over_speeding|rash_driving", "description": "brief description", "severity": "high|medium|low", "fine": 500, "plate": "XX-00-XX-0000 or null", "confidence": 0.0-1.0}],
  "accidents": [{"description": "brief description", "severity": "high|medium|low", "confidence": 0.0-1.0}],
  "abnormal_activities": [{"type": "fighting|jaywalking|obstruction", "description": "brief", "confidence": 0.0-1.0}],
  "person_count": 0,
  "vehicle_count": 0,
  "overall_risk": "high|medium|low|safe",
  "summary": "One line summary of the scene"
}

If nothing is detected, return empty arrays. Always return valid JSON only.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          {
            role: "user",
            content: [
              {
                type: "image_url",
                image_url: {
                  url: imageBase64.startsWith("data:")
                    ? imageBase64
                    : `data:image/jpeg;base64,${imageBase64}`,
                },
              },
              {
                type: "text",
                text: `Analyze this traffic camera frame. Timestamp: ${frameTimestamp || "unknown"}. Source: ${sourceVideo || "uploaded video"}. Detect all vehicles, plates, violations, accidents, and abnormal activities. Return JSON only.`,
              },
            ],
          },
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limited. Please wait and try again." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Add funds in Settings > Workspace > Usage." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errText = await response.text();
      console.error("AI gateway error:", response.status, errText);
      throw new Error(`AI gateway returned ${response.status}`);
    }

    const aiResult = await response.json();
    const content = aiResult.choices?.[0]?.message?.content || "";

    // Parse the JSON from the AI response (strip markdown fences if present)
    let cleanedContent = content.trim();
    if (cleanedContent.startsWith("```")) {
      cleanedContent = cleanedContent.replace(/^```(?:json)?\n?/, "").replace(/\n?```$/, "");
    }

    let detection;
    try {
      detection = JSON.parse(cleanedContent);
    } catch {
      console.error("Failed to parse AI response:", content);
      detection = {
        vehicles: [],
        violations: [],
        accidents: [],
        abnormal_activities: [],
        person_count: 0,
        vehicle_count: 0,
        overall_risk: "safe",
        summary: "Could not parse AI detection results",
        raw_response: content,
      };
    }

    return new Response(JSON.stringify({ success: true, detection, frameTimestamp }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("analyze-frame error:", e);
    const msg = e instanceof Error ? e.message : "Unknown error";
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
