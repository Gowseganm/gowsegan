
CREATE TABLE public.violations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  violation_type TEXT NOT NULL,
  description TEXT,
  severity TEXT NOT NULL CHECK (severity IN ('high', 'medium', 'low')),
  fine INTEGER NOT NULL DEFAULT 0,
  plate TEXT,
  confidence NUMERIC(4,3),
  vehicle_type TEXT,
  frame_timestamp NUMERIC,
  source_video TEXT,
  overall_risk TEXT,
  summary TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.violations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert violations" ON public.violations FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can read violations" ON public.violations FOR SELECT USING (true);
